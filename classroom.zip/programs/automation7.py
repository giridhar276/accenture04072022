
import os

try:
    for val in range(1,51):
        dirname = "dir" + str(val)
        os.mkdir(dirname)
except Exception as err:
    print(err)
    
    
    
    
try:
    for val in range(1,51):
        dirname = "dir" + str(val)
        os.rmdir(dirname)
except Exception as err:
    print(err)    