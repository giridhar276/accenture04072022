import pymysql
import csv
try:
    #############################
    # step1 - establish the step
    #############################
    conn = pymysql.connect(host='127.0.0.1',port=3306,user='root',password='india@123',database='information')
    if conn:
        # inorder to navigate the records
        cursor = conn.cursor()
        #############################
        # step2 - define query
        #############################
        with open("realestate.csv","r") as fobj:
            reader = csv.reader(fobj)
            for line in reader:                
                query = "insert into realestate values('{}','{}')".format(line[0],line[1])
                #############################
                # step3 - execute theq query
                #############################
                cursor.execute(query)
                #print(cursor.rowcount,"record inserted")
                # to make the changes permanent
        conn.commit()
        #############################
        #step5 -  close the connection
        #############################
        conn.close()
        
except Exception as err:
    print(err)