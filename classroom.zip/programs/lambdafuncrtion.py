# write a program to read the  list and display the below output
alist = [10,20,30,40]

# [15,25,35,45]

blist = []
for val in alist:
    blist.append(val + 5)
print(blist)

def add(x):
    return x + 5

total = add(5)
print(total)

###########################
# lambda function : lambda is the inline function in python
# lambda is single liner function
# instead of calling function body... lambda is invoked
# Advantage : faster in terms of execution and performance
# anonymous function
# inline function  
##########################
# syntax
#functionname = lambda variables : expression
add = lambda x  : x+5

total = add(5)
print(total)


















