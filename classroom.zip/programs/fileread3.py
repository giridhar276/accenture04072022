

#using csv library

import csv

with open("languages.txt","r") as fobj:
    # convert fobj to csv library understandable format
    # convert fobj to csv object
    reader = csv.reader(fobj)
    for line in reader:
        print(line[0])