# inheritance is used for code resusability
# Any class inheriting from another class (also called a Parent class)
# inherits the methods and attributes from the Parent class.

# Parent # Base # Super
class Date:   
    def get_date(self):
        print("2016-05-14")
        

# Child # inherited # subclass    
class Time(Date): 
    def get_time(self):
        print("08:00:00")        
        
dt = Date()
dt.get_date()  # Accesing the `get_date()` method of `Date`
print("--------")        

tm = Time()
tm.get_time()
tm.get_date()