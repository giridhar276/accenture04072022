


#using csv library

import csv

with open("realestate.csv","r") as fobj:
    # convert fobj to csv library understandable format
    # convert fobj to csv object
    reader = csv.reader(fobj)
    for line in reader:
        print("Street:",line[0])
        print("CIty  :",line[1])
        