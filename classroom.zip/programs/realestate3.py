import sys
import csv
try:
    cityset = set()
    filename = input('Enter any filename:')
    with open(filename,"r") as fobj:
        reader = csv.reader(fobj)
        # for processing
        for line in reader:
            city =line[1]
            cityset.add(city)
        # display all unique cities
        for city in cityset:
            print(city)
except FileNotFoundError as err:
    print("file not found")
    print("system defined error:",err)
except IndexError as err:
    print("Index not found")
    print(err)
except (TypeError,KeyError) as err:
    print("Invalid operation")
    print(err)
except Exception as err:
    print("some other error") 
    print(sys.exc_info())
finally:
    print("this will be executed all the times")