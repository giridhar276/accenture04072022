

## fixed arguments

def add(a,b):
    c = a+b
    print("Sum:", c)

add(10,20)
