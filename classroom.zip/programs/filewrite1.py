## method1
## traditional way  # regular way
# opening in write mode
fobj  = open("customers.txt","w")
# writing to the file
fobj.write("python programming\n")
fobj.write("unix shell\n")
fobj.write("hadoop\n")
# closing the file
fobj.close()


