

import pymysql
import csv
class DBConnect:
    def __init__(self,host,port,user,password,db):
        self.host = host
        ..
        ..
        self.db = db
    
    def connect(self):
        self.conn = pymysql.connect(self.host,self.port,self.user,self.password,self.db)
        if self.conn:
            self.cursor = self.conn.cursor()
        
    def fileToDatabase(self):
        with open("realestate.csv","r") as self.fobj:
            self.reader = csv.reader(self.fobj)
            for line in self.reader:
                query = "insert into realestate values('{}','{}')".format(line[0],line[1])
                self.cursor.execute(query)
            
        
        
    
db1 = DBConnect('127.0.0.1',3306,'root','india@123','information')
db1.connect()
db1.fileToDatabase()