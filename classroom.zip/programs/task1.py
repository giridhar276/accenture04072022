'''
Define some list as below

alist = ["google","oracle","microsoft"]

Output:

Output:
http://www.google.com
http://www/.oracle.com
http://www.microsoft.com
'''



alist = ["google","oracle","microsoft"]

for item in alist:
    domain = "http://www." + item + ".com"
    print(domain)
    



domains = ["google","www.unix","oracle.com"]

for item in domains:
    if not item.endswith(".com"):
        item = item + ".com"
    if not item.startswith("www."):
        item = "www." + item
    print(item)
        
        
        
'''
Write a Python program to display the below IP addresses

192.168.0.1
192.168.0.2
192.168.0.3
..
..
192.168.0.10
'''      

fixed = "192.168.0."
for val in range(1,11):
    print(fixed + str(val))
    
    
    

for val in range(1,11):
    print("192.168.0.{}".format(val))
    
    
    
IP_address = "192.168."

for value in range(0,2):
    IP_address1 = IP_address + str(value) 
    for value in range(1,11):
        IP_address2 = IP_address1+"."+str(value)
        print(IP_address2)
    
    
    

        

        
        
        
        
        
        
        
        
        
        
        
        
        

