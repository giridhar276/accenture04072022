# method1
# reading line by line using fobj
# here fobj acts as cursor or file handler or reference
with open("languages.txt","r") as fobj:
    for line in fobj:
        # optional: to remove whitespaces
        line = line.strip()
        print(line.split(",")[0])
        
        
# method2 : reading all the lines at once
# using fobj.readlines()        
with open("languages.txt","r") as fobj:
    print(fobj.readlines())
    
    
# using fobj.readlines() display only 2nd and 3rd line    
with open("languages.txt","r") as fobj:
    print(fobj.readlines()[2:4])    