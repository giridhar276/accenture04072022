
#2. Write a Python program to display all the files and directories from the C:\\
import os

try:
    files = os.listdir("c:\\")
    for file in files:
        print(file)
except Exception as err:
    print(err)
    