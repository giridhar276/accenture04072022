

#3. Write a Python program to display ONLY .csv files line by line in the for loop from the current directory.

import os

try:
    files = os.listdir()
    for file in files:
        if file.endswith(".csv"):
            print(file)
except Exception as err:
    print(err)
    