

#Write a Python program to read realestate.csv and replace all the lines containing SACRAMENTO with HYDERABAD and write the output to  07052022.csv

try:

    # read operation
    with open("realestate.csv","r") as fobj:
        # write operation
        with open("07052022.csv","w") as fw:
            for line in fobj:
                # to remove whitespaces
                line = line.strip()
                final_line = line.replace("SACRAMENTO",'HYDERABAD')
                fw.write(final_line + "\n")
except FileNotFoundError as err:
    print("file not found")
    print("system defined error:",err)
except IndexError as err:
    print("Index not found")
    print(err)
except (TypeError,KeyError) as err:
    print("Invalid operation")
    print(err)
except Exception as err:
    print("some other error")   
finally:
    print("this will be executed all the times")
