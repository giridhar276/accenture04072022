
import os

try:
    files = os.listdir()
    for file in files:
        print(file)
except Exception as err:
    print(err)
    