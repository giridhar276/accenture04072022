# traditional way # regular way
#input
alist = [10,20,30,40]
# [15,25,35,45]
blist = []
for val in alist:
    blist.append(val + 5)
print(blist)

##### map() is used if we want to perform some activity on all the elements of the list or tuple
# pythonic way
### method2
alist = [10,20,30,40]
def increment(x):
    return x + 5
#map(function,iterable)
print(list(map(increment,alist)))


#method3
alist = [10,20,30,40]
print(list(map(lambda x: x+5,alist)))


# converting strings to int values
alist = ['1','2','3','4']
print(list(map(lambda x: int(x),alist)))


data  = ["google","java","oracle"]
#["www.google.com","www.java.com","www.oracle.com"]
print(list(map(lambda x: "www." + x + ".com",data)))

alist = [1,2,3,4,5,6,12,3,45,34,67,66]   


### write a program to display all the even numbers


# regular approach
for val in alist:
    if val % 2 == 0:
        print(val)


# pythonic way
alist = [1,2,3,4,5,6,12,3,45,34,67,66]   
# filter(function,iterable)
print(list(filter(lambda x : x%2==0,alist )))

############################
# list comprehension
#############################basic syntax
#[<expression> for <element> in <iterable> ]

# with the combination of if condition
#[<expression> for <element> in <iterable>  if <condition>]

squares = [ x * x for x in (1, 2, 3, 4) ]
print(squares)

# converting list of strings to lower case
output = [s.lower() for s in "I stay in Hyderabad"]
print(output)

# remove any commas from the end of strings in a list
output = [word.strip(',') for word in ['Python,', 'is,', 'general', 'purpose,', 'programming,', 'language,'] ]
print(output)

name = 'python programming'
# replace all characters with * other than the vowels
output = [x if x in 'aeiou' else '*' for x in 'python programming']
print(output)

## display odd number
# display all the range of even numbers
output = [x for x in range(1,20) if x % 2 == 0]
print(output)


for x in range(1,20):
    if x % 2 == 0:
        print(x)
    
























