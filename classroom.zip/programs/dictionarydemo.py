book = { "chap1":10 ,"chap2":20 ,"chap3":30}
print(book)
print(book["chap9"])
# display individual value
print(book["chap1"])  # 10
print(book["chap2"])  # 20
#print(book["chap5"])  
# add new key:value pairs
book["chap4"] = 40
book["chap5"] = 50
print("updated dictionary:", book)

# display only keys
print(book.keys())

# only values
print(book.values())

# all key:value pairs
print(book.items())

# remove chap2 key
book.pop("chap2")
print("After pop:", book)

# remove random key:value
book.popitem()
print(book)

# combine 2 dictionaries
book = {'chap1': 10, 'chap2': 20, 'chap3': 30, 'chap4': 40, 'chap5': 50}
newbook = {"chap6":60,"chap7":70}

finaldict = {**book,**newbook}
print(finaldict)
































