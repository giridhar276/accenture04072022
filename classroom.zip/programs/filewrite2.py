###################
# context manager
###################
# pythonic way  # modern way
# file wil be closed automatically .. not required to close
# if any line starts with keyword with... we call it as context manager

with open("customers.txt","a") as fobj:
    # writing to the file
    fobj.write("python programming\n")
    fobj.write("unix shell\n")
    fobj.write("hadoop\n")
