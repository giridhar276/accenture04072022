###################################################
######### Objects should be same type##############
####################################################

'''
final = "hello" + 9
print(final)
'''

final = "hello" + str(9)
print(final)



final = [10,20,30] + [40,50,60]
print(final)

final = [10,20,30] + list((40,50,60))
print(final)