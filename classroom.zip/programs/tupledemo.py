# changes are possible in list
alist = [10,20,30,40]
alist[0] = 100
print(alist)


#####################################################
atup = (10,20,30,40)
atup[0] = 100
print(atup)

## typecasting # converting from one object to another
atup = (10,20,30,40)
# converting to list
alist = list(atup)
#making changes
alist.append(83)
# reconcoverting back to tuple
atup = tuple(alist)
print(atup)



atup = (12,20,34,30)

print(atup.count(12))



















