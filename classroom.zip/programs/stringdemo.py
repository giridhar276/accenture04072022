name  = "python"
print(name)
print("I love", name)
print("python","java","unix")

name = "python programming"
print(name[0])
print(name[1])
print(name[2])
# string slicing : extracting slice of the string
# string[start:stop:incremental]
print(name[0:4])
print(name[3:10])
print(name[0:10])
print(name[:10])
print(name[::])  # everything
print(name[:])
print(name[0:18:2])
print(name[1:18:2])
print(name[::3])
print(name[0::3])

print(name[-1])
print(name[-2])
print(name[-4:-2])
print(name[::])
print(name[::-1])
print(name[::-2])

name = "python programming"
print(name.startswith('z'))
print(name.startswith('p'))
print(name.endswith('g'))
print(name.endswith('z'))
print(name.isupper())
print(name.islower())
print(name.replace('python', 'c'))
# to make the change permanent
#name = name.replace('python', 'c')
print(name.find('gram'))    # if existing.. it returns the index of g
print(name.find('qwe'))    # if returns -1 if not existing
print(name)
getcount = name.count('p')
print(getcount)
#     
     
query = "I love {} and {}"
print(query.format('unix','python'))
print(query.format('java','oracle'))

print(name.capitalize())

bname = 'python'
print(bname.center(40))
print(bname.center(40,"*"))

cname = " python   "
print(len(cname))
print(len(cname.lstrip()))
print(len(cname.rstrip()))

dname = "python:perl:java"

print(dname.split(":")[0])

print(name.upper())
print(name.lower())







print(name.isupper())
print(name.islower())


a = 10
b = 2

if a > b :
    print("A is greater than B")
    print("inside if")
    print("still inside if")
else:
    print("B is greater than A")
    print("Inside else")
    print("Still inside else")

name = "python"
if name.isupper():
    print("String is upper")
elif name.isnumeric():
    print("String is numeric")
elif name.islower():
    print("String is lower")
else:
    print("Its something else")

if name.startswith("py"):
    print("its python programming")
elif name.startswith("jy"):
    print("its java programming")
else:
    print("its someother language")    
    
    

### for loop

for i in range(1,11):
    print(i)

# string 
name  = "python"
for char in name:
    print(char)

# list
alist = [10,20,30]
for val in alist:
    print(val)



# range(start,stop,step)
for i in range(1,11,2):  # odd numbers
    print(i)
    
for i in range(2,11,2):  # odd numbers
    print(i)
    
    

for i in range(11,0,-1):  # odd numbers
    print(i)



for i in range(1,11):  # odd numbers
    if i in range(3,10):
        print(i)
    





