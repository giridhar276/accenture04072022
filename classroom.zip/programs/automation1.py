

### list all the files
import os

# display from current working directory
print(os.listdir())

# display all the files and folders from C:
print(os.listdir("C:\\"))

# create a directory
os.mkdir("examples")

# display date
import datetime
print(datetime.datetime.now())

# display from current working directory
#print(os.listdir())
for file in os.listdir():
    print(file)

# delete file
os.remove('07052022.csv')




# copy files





















