
aset = {10,10,20,30,30,20,20}
bset = {30,30,30,30,40,40,50,50}

print(aset)
print(bset)

# union operation
print(aset.union(bset))

# intersection operation
print(aset.intersection(bset))

# A - B
print(aset - bset)

print(aset.issubset(bset))
print(aset.issubset(bset))


