
# All the employees share the same properties
# all the properties shared across all the employees
# are defined in class
class Employee:
    def displayEmployee(self):
        print("Employee name :","ram")
    def displayAddress(self):
        print("Hyderabad")
        
# object creation or object initialization
emp1 = Employee()       
emp1.displayEmployee()
emp1.displayAddress()        
        

emp2 = Employee()       
emp2.displayEmployee()
emp2.displayAddress()   