class Employee:
    # constructor
    def __init__(self,name,address):
        #self internally contains the object thru which it is invoked
        self.name = name
        self.address = address
    def displayDetails(self):
        print("Employee name :", self.name)
        print("Employee add  :", self.address)
        
# object creation or object initialization
# constructor will be invoked automatically when the object is created
emp1 = Employee('ram','hyderabad')      
emp1.displayDetails()        
        
# object creation or object initialization
emp2 = Employee('rita','US')     
emp2.displayDetails()  