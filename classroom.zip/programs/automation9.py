
import sys
import psutil
import os
import shutil
try:
    print(shutil.disk_usage("D:\\"))
    print(psutil.cpu_percent())
    print(psutil.virtual_memory())
    # you can convert that object to a dictionary 
    print(dict(psutil.virtual_memory()._asdict()))
except Exception as err:
    print(err)
    print(sys.exc_info())
