

import csv
citylist = list()   # emptyset
with open("realestate.csv","r") as fobj:
    # convert fobj to csv library understandable format
    # convert fobj to csv object
    reader = csv.reader(fobj)
    # processing
    for line in reader:
        city = line[1]
        #print(city)
        citylist.append(city)
    # display the output
    for city in set(citylist):
        print(city.ljust(20), citylist.count(city),"times")
