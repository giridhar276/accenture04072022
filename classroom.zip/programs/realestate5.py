
#write a program to display all hte records where the prices > 60000.


import sys

try:
    cityset = set()
    #filename = input('Enter any filename:')
    with open("realestate.csv","r") as fobj:
        # just reading first line which is header and storing to some object
        header = fobj.readline()
        # for processing
        for line in fobj:
            data = line.split(",")
            # converting price to integer to compare
            price =int(data[9])
            if price > 60000:
                print(line)

except FileNotFoundError as err:
    print("file not found")
    print("system defined error:",err)
except IndexError as err:
    print("Index not found")
    print(err)
except (TypeError,KeyError) as err:
    print("Invalid operation")
    print(err)
except Exception as err:
    print("some other error") 
    print(sys.exc_info())
finally:
    print("this will be executed all the times")