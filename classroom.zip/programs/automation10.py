
### write a program to copy all the files from source to destination folder
 
#source has some files
source = r'D:\trainings\accenture04072022\programs\source'
destination = r'D:\trainings\accenture04072022\programs\destination'


import shutil
import os

try:
    for file in os.listdir(source):
        os.chdir(source)
        shutil.copy(file,destination)
        print(file,"copied to",destination)
except Exception as err:
    print(err)















'''
#method1
source = 'D:\trainings\accenture04072022\programs\source'
#method2  - using \\
source = 'D:\\trainings\\accenture04072022\\programs\\source'
#method3 - prefix with r   ( raw)
source = r'D:\trainings\accenture04072022\programs\source'
'''