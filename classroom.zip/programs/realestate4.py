

try:
    filename = input('Enter any filename:')
    with open(filename,"r") as fobj:
        for line in fobj:
            # to remove whitespaces
            line = line.strip()
            print(line.replace("SACRAMENTO",'HYDERABAD'))
except FileNotFoundError as err:
    print("file not found")
    print("system defined error:",err)
except IndexError as err:
    print("Index not found")
    print(err)
except (TypeError,KeyError) as err:
    print("Invalid operation")
    print(err)
except Exception as err:
    print("some other error")   
finally:
    print("this will be executed all the times")