

'''
write a program to delete all .csv files from your current directory ( present working directory) with proper exception handling
( before running the program take the backup of the folder)
'''

import os
try:
    for file in os.listdir():
        if os.path.isfile(file) and file.endswith(".csv"):
            os.remove(file)
            print(file,"deleted")
except Exception as err:
    print(err)
    
    
    