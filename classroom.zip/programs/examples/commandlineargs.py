
#### command line arguments
#### passing the arguments in the runtime is known as command line arugment
import sys


name = sys.argv
print(name)