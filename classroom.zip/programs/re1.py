
# just like grep command in linux
# regular expression
import re
with open("languages.txt") as fobj:
    for line in fobj:
        if re.search("python", line):
            print(line)
            

## display all the lines starting with python
## ^python - starting with python
import re
with open("languages.txt") as fobj:
    for line in fobj:
        if re.search("^python", line):
            print(line)
            
            
## display all the lines ending with python
## python$ -  ending with python
import re
with open("languages.txt") as fobj:
    for line in fobj:
        if re.search("python$", line):
            print(line)
            
#pyt*hon :  zero or more occurences of the preceding character
import re
with open("languages.txt") as fobj:
    for line in fobj:
        if re.search("pyt*hon", line):
            print(line)            
                                
#pyt+hon :  one or more occurences of the preceding character
# in the above string... t should exist for atleast once
import re
with open("languages.txt") as fobj:
    for line in fobj:
        if re.search("pyt+hon", line):
            print(line)              
                 
#(pattern1|pattern2) : display all the lines having either
# pattern1 or pattern2            
import re
with open("languages.txt") as fobj:
    for line in fobj:
        if re.search("unix|java|perl", line):
            print(line)              
 
# pyt{min,max}hon -- t should be in the range of min to max                       
# pyt{2,5}hon  ----  pytthon  pyttthon pytttthon pyttttthon
import re
with open("languages.txt") as fobj:
    for line in fobj:
        if re.search("pyt{2,5}hon", line):
            print(line)             
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            