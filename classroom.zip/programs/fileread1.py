# reading line by line using fobj
# here fobj acts as cursor or file handler or reference
with open("languages.txt","r") as fobj:
    for line in fobj:
        print(line.strip())