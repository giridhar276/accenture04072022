

import pymysql

try:
    #############################
    # step1 - establish the step
    #############################
    fobj = open("output.csv","w")
    conn = pymysql.connect(host='127.0.0.1',port=3306,user='root',password='india@123',database='information')
    if conn:
        # inorder to navigate the records
        cursor = conn.cursor()
        #############################
        # step2 - define query
        #############################
        query = "select * from realestate"
        #############################
        # step3 - execute theq query
        #############################
        cursor.execute(query)
        #############################
        #step4  - display records
        #############################
        for record in cursor.fetchall():
            fobj.write(",".join(record) + "\n")
        #############################
        #step5 -  close the connection
        #############################
        conn.close()
        fobj.close()
        
except Exception as err:
    print(err)