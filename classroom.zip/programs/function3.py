

## default arguments
# if any object is prefixed with *....  
#it is called tuple
def add(*args):
    print(args)
add(10,20,30,40,1,2,3,"unix","java",2332.2)



# displaying line by line
def add(*args):
    for val in args:
        print(val)
add(10,20,30,40,1,2,3)














