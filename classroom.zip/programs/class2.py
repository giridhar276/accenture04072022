
class Employee:
    def getDetails(self,name,address):
        #self internally contains the object thru which it is invoked
        self.name = name
        self.address = address
    def displayDetails(self):
        print("Employee name :", self.name)
        print("Employee add  :", self.address)
        
# object creation or object initialization
emp1 = Employee()       
emp1.getDetails('ram','hyderabad')
emp1.displayDetails()        
        
# object creation or object initialization
emp2 = Employee()       
emp2.getDetails('rita','US')
emp2.displayDetails()  