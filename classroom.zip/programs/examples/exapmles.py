

name = "unix"
print(name * 2)

output = (10,20,30)

print(output * 2)


# list comprehension
output = [x for x in 'aabbcc']
print(output)
print(set(output))



name = "python"
print(name)
print(id(name))

#id() - identity of the object
alist =[10,20,30]
print(id(alist))    # unique reference
print(id(alist[0]))



book = {"chap1":10,"chap2":20}
print(book["chap1"]) #10
print(book[0])



	
Which of the following will delete key_value pair for key="tiger" in dictionary? 
dic={"lion":"wild","tiger":"wild","cat":"domestic","dog":"domestic"}
dic.pop('tiger')
print(dic)





a = "cpp"
b = "def"

c = a + b
print(c)   #cppdef




What is the output of the following code? 


list1 = 
list1 += 'de'  
#list1 = ['a','b','c']  + "de"    
print(list1)



val = 10
val = val + 1      # val+=1





