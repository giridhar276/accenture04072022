

with open("customers.txt","w") as fobj:
    # writing to the file
    fobj.write("python programming\n")
    fobj.write("unix shell\n")
    fobj.write("hadoop\n")
