alist = [12,34,45,3,65,65,65]
# display count
print(alist.count(650))

print(alist)
print("elements are", alist)

# add single object to the list
alist.append(98)
print('After appending :',alist)

# add multiple values
alist.extend([18,23,49])
print('After extending :',alist)

# alist.insert(index,value)
alist.insert(1,300)
print('After inserting', alist)

# list.pop(index)
# value at that index will be removed
alist.pop(1) 
print('After pop operation', alist)
alist.pop(1) 
print('After pop operation', alist)

# list.remove(element)  # elements will be deleted if existing
alist.remove(65)
print('After removing :',alist)


if 65 in alist:
    alist.remove(65)
    print('After removing :',alist)
else:
    print("value doesn't exist")




# ascending order
alist.sort()
print('Ascending order', alist)

# descending order
alist.sort(reverse= True)
print("Descending order :",alist)


alist = [45,56,3,67,32,7]
alist.reverse()
print("After reversing :",alist)








