
# api programming
import requests

url = "https://www.google.com/"

# here , we are trying to get the page ( access the page)
response = requests.get(url)

if response.status_code == 200:
    print("successful...!")
    # reading the complete web page
    print(response.text)
else:
    print(response.status_code)
    print("unable to open the page")