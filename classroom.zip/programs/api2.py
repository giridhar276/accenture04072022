

# api programming
import requests
import sys

url =  sys.argv[1]

# here , we are trying to get the page ( access the page)
response = requests.get(url)

if response.status_code == 200:
    print("successful...!")
    # reading the complete web page
    #print(response.text)
else:
    print(response.status_code)
    print("unable to open the page")