


first = input("Enter first number:")
second = input("Enter second number:")

print(type(first))

total = first + second

print("sum of two numbers :", total)