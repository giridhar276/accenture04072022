


name = "python"


data = input('Enter any string :')
print("you entered",data)