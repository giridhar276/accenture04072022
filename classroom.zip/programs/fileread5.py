#using csv library

import csv
cityset = set()   # emptyset
with open("realestate.csv","r") as fobj:
    # convert fobj to csv library understandable format
    # convert fobj to csv object
    reader = csv.reader(fobj)
    # processing
    for line in reader:
        city = line[1]
        #print(city)
        cityset.add(city)
    # display the output
    for city in cityset:
        print(city)




# in dictionary, keys are always unique
import csv
citydict = dict()   # emptyset
with open("realestate.csv","r") as fobj:
    # convert fobj to csv library understandable format
    # convert fobj to csv object
    reader = csv.reader(fobj)
    # processing
    for line in reader:
        city = line[1]
        #print(city)
        # converting city as the dictionary key
        citydict[city] = 1
    
    # display the output
    for city in citydict.keys():
        print(city)



aset = {10,10,10,20,30,20,10}
aset.add(40)
print(aset)
aset.add(10)
print(aset)