'''
5. Write a Python program to display all the files and folders separately and its count also.

files
------
file1
file2
file3

Total no. of files : 504

directories
------------
dir1
dir2
dir3

Total no. of direcotires : 453
'''
import os
files_list = []
dirs_list =[]

for file in os.listdir():
    if os.path.isfile(file):
        files_list.append(file)
    elif os.path.isdir(file):
        dirs_list.append(file)
        
        
# display files
print("*********** Files ***************")
for file in files_list:
    print(file)
print("********************************")
print("TOtal no. of files :",len(files_list))
print()
print("*********** directories *************")
for file in dirs_list:
    print(dir)
print("********************************")    
print("Total no. of direcotires :", len(dirs_list))















