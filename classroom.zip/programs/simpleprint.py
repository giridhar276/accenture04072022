


print("python programming")
print("python programming")
print("python programming")



val = 10
print(val)




val= 10
val = 100
print(val)